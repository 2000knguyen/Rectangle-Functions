/*
Name: Kendrick Nguyen
Date: 11 March 2021
Class: CECS 275
Desc:The purpose of this lab is to make a program that lets users place rectangles onto a map using previous concepts learned and the new rectangle function
*/
#include <iostream>
#include "CheckInput.h"
using namespace std;

/* Creates the rect function and that's about it
 */
struct Rectangle{
  int x;
  int y;
  int Width;
  int Height;
};

/* Takes the array and displays it
 * @param ptrArr gives the array to then display it
 * Note: Taken from previous labs
 */
void displayGrid(char **ptrArr){
  for (int i = 0; i < 30; i++){
    for (int j = 0; j < 30; j++){
      cout << ptrArr[i][j] << " ";
      if (j==29){                   // Started from zero
        cout<<endl;
      }
    }
  }
}

/* Passes in the user input to get the dimensions and locations of the rectangles
 * @param rectNum gives in the rectangle to be manipulated 1 2 3 4 5
 * @return rect gives back the rectangle function to the main
 */
Rectangle getRect(int RectNum){
  cout << "Please enter x location of rectangle " << RectNum << " (1-30): ";
  int Xlocation = getIntRange(1, 30) - 1;
  cout << "Please enter y location of rectangle " << RectNum << " (1-30): ";
  int Ylocation = getIntRange(1, 30) - 1;
  int xDiff = 30 - Xlocation;     // Gives us the range of which we can use to scale the dimensions of the rectangle
  int yDiff = 30 - Ylocation;     // Gives us the range of which we can use to scale the dimensions of the rectangle
  cout << "Please enter width of rectangle " << RectNum << " (1-" << xDiff << "): ";
  int rectWidth = getIntRange(1, 30 - Xlocation);   // Do this because otherwise the rectangle can get out of the area given
  cout << "Please enter height of rectangle "<< RectNum << " (1-" << yDiff << "): ";
  int rectHeight = getIntRange(1, 30 - Ylocation);  // Do this because otherwise the rectangle can get out of the area given
  Rectangle rect = {Xlocation, Ylocation, rectWidth, rectHeight};
  return rect;
}

/* Passes the 2D array, the rectangle function, and the display variable used
 * @param pointArr is used to create the rectangle
 * @param rect is used to get the Height and Width of the Rectangle
 * @param c gives the char that the rectangle will be filled with X ^ * O ~
 * @return the array to the main
 * Note: We use this to draw the rectangle using the x nand y location that the user gave us, as well as the width and height of the rectangle, the char c is what we made
 */
void fillRect(char **pointArr, Rectangle &rect, char c){
  int Height = rect.y + rect.Height;      // ex: y = 1, height = 1, index on array [1]
  int Width = rect.x + rect.Width;        // ex: x = 3, width = 4, index on array [6]
  for(int i = rect.y; i < Height; i++){   // fills given location with c
    for(int j = rect.x; j < Width; j++){
      pointArr[i][j] = c;
    }
  }
}

/* This is the main function and that's about it
 */
int main() {
  cout << "How many rectangles would you like to draw (1-5): ";
  int userIn = getIntRange(1,5);
  Rectangle *rect = new Rectangle[userIn];
  int rectNum = 1;
  char **Arr = new char*[30];
  for(int i = 0; i < 30; i++){
    Arr[i] = new char[30];            // This creates a new rectangle for the given input
  }
  for(int i = 0; i < 30; i++){      //creates the area of the rectangle
    for(int j = 0; j < 30; j++){
      Arr[i][j] = '.';
    }
  }
  for(int i = 0; i < userIn; i++){
    rect[i] = getRect(rectNum);
    if(i == 0){
      fillRect(Arr, rect[i], 'C');    //Calls fillRect to add rectangles to the area
    }
    else if(i == 1){
      fillRect(Arr, rect[i], '*');
    }
    else if(i == 2){
      fillRect(Arr, rect[i], 'P');
    }
    else if(i == 3){
      fillRect(Arr, rect[i], '-');
    }
    else if(i == 4){
      fillRect(Arr, rect[i], 'O');
    }
    rectNum += 1;
  }
  displayGrid(Arr);       // Used in the end to display the entirety of the area after everything is done
  return 0;
}